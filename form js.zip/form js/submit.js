
 let firstName;
 let lastName;

 function storeData() {
     firstName = document.getElementById("firstName").value;
     lastName = document.getElementById("lastName").value;
     alert("کاربر ذخیره شد!");
 }

 function showData() {
     if (!firstName || !lastName) {
         alert("لطفا نام و نام خانوادگی خود را وارد کنید");
     } else {
         alert("Welcome, " + firstName + " " + lastName + "!");
     }
 }